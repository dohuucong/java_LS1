package lession01;

public class SP3_6 {
    public static void main(String[] args) {
        int empNumber;
        float salary;
        double shareBalance = 456790.897;
        char gender = 'M';
        boolean ownVehicle = false;
        empNumber = 101;
        salary = 6789.50f;
        System.out.println("Employee Number" + empNumber);
        System.out.println("Salary : " + salary);
        System.out.println("Gender : " + gender);
        System.out.println("Share Balance : " + shareBalance);
        System.out.println("Owns vehicle : " + ownVehicle);
    }
}
