package lession01;

public class SP4_3 {
    public static void main(String[] args) {
        int number = 11, remainder;
        remainder = number % 2;
        if(remainder == 0){
            System.out.println("Number is even.");
        }else
            System.out.println("Number is Odd");
    }
}
