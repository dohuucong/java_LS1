package lession01;

public class SP3_7 {
    public static void main(String[] args) {
        System.out.println("Java \t Programming \n Language");
        System.out.println("Tom \" Dick \" Harry");
    }
}
