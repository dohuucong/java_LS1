package lession01;

public class SP5_2 {
    public static void main(String[] args) {
        int num1 = 1;
        int num2 = 30;
        while (++num1 < --num2)
            System.out.println("Midpoint is : " + num1);
    }
}
