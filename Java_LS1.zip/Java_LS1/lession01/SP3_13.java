package lession01;

public class SP3_13 {
    public static void main(String[] args) {
        int num = 2;
        double result = num * num;
        System.out.format("The square root of %d is %f.%n", num, result);
    }
}
