package lession01;

public class SP3_19 {
    public static void main(String[] args) {
        int first = 10;
        int second = 20;
        System.out.println((first == 30) && (second == 20));
        System.out.println((first == 30) || (second == 20));
    }
}
