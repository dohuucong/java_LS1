package lession01;

public class SP3_18 {
    public static void main(String[] args) {
        int value1 = 10;
        int value2 = 20;
        System.out.print("value1 == value2 : ");
        System.out.println(value1 == value2);
        System.out.print("value1 != value2 : ");
        System.out.println(value1 != value2);
        System.out.print("value1 > value2 : ");
        System.out.println(value1 > value2);
        System.out.print("value1 < value2 : ");
        System.out.println(value1 < value2);
        System.out.print("value1 <= value2 : ");
        System.out.println(value1 <= value2);
    }
}
