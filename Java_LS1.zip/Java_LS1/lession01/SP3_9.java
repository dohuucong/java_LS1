package lession01;

public class SP3_9 {
    public static void main(String[] args) {
        final double PI = 3.14159;
        double radius = 5.87;
        double area;

        area = PI * radius * radius;
        System.out.println("Area of Cricle is : " + area);
    }
}
