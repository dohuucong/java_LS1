package lab01;

public class fiveIntergerSum {
    public static void main(String[] args) {
        int num1 = 11;
        int num2 = 22;
        int num3 = 33;
        int num4 = 44;
        int num5 = 55;
        int sum;
        sum = num1 + num2 + num3 + num4 + num5;
        System.out.printf("The sum is ");
        System.out.println(sum);
    }
}
