package lab01;

public class PrintTest {
    public static void main(String[] args) {
        System.out.println("Hello, world!");
        System.out.println("Hello world again !");
        System.out.println();
        System.out.print("Hello world");
        System.out.print("Hello world again");
        System.out.println();
        System.out.print("Hello, ");
        System.out.print(" ");
        System.out.println("world");
        System.out.println("Hello, world!");
    }
}
