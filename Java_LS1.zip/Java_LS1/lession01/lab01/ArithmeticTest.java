package lab01;

public class ArithmeticTest {
    public static void main(String[] args) {
//        int num1 = 98;
//        int num2 = 5;
//        int sum, difference, product, quotient, remainder;
//
//        sum = num1 + num2;
//        difference = num1 - num2;
//        product = num1 * num2;
//        quotient = num1 / num2;
//        remainder = num1 % num2;
//
//        System.out.printf("The sum, difference, product, quotient, remainder of ");
//        System.out.printf("number1 ");
//        System.out.printf(" and ");
//        System.out.printf("number2");
//        System.out.printf(" are ");
//        System.out.print(sum);
//        System.out.print(", ");
//        System.out.print(difference);
//        System.out.printf(", ");
//        System.out.print(product);
//        System.out.printf(", ");
//        System.out.print(quotient);
//        System.out.printf(", and ");
//        System.out.println(remainder);
//        ++num1;
//        --num2;
//        System.out.println("Number1 after increment is " +num1);
//        System.out.println("Number2 after decrement is " +num2);
//        quotient = num1 / num2;
//        System.out.println("The new quotient of " + num1 + " and " + num2 + " is " + quotient);
//        System.out.printf("The new quotient of ");
//        System.out.print(num1);
//        System.out.printf(" and ");
//        System.out.print(num2);
//        System.out.printf(" is ");
//        System.out.println(quotient);
        int num1 = 10;
        int num2 = 15;
        int num3 = 77;
        int sum, product;
        sum = 31*num1 + 17*num2;
        product = num1 * num2 * num3;
        System.out.println("Sum of num1 and num2 is " + sum);
        System.out.println("Product of three number is " + product);
    }
}
