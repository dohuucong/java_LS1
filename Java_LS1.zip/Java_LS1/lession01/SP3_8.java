package lession01;

public class SP3_8 {
    public static void main(String[] args) {
        System.out.println("\u0048\u0065\u006C\u006C\u006F" + "!\n");
        System.out.println("Bl\141ke\"2007\"");
    }
}
